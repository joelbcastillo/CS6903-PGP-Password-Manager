# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['cs6903_pgp_password_manager']

package_data = \
{'': ['*'],
 'cs6903_pgp_password_manager': ['static/*',
                                 'static/lib/*',
                                 'templates/*',
                                 'templates/public/*']}

install_requires = \
['Flask-Migrate>=2.7.0,<3.0.0',
 'Flask-RESTful>=0.3.8,<0.4.0',
 'Flask-SQLAlchemy>=2.5.1,<3.0.0',
 'Flask>=1.1.2,<2.0.0',
 'ipdb>=0.13.7,<0.14.0',
 'python-dotenv>=0.17.1,<0.18.0',
 'python-gnupg>=0.4.7,<0.5.0',
 'requests>=2.25.1,<3.0.0']

entry_points = \
{'console_scripts': ['CS6903-PGP-Password-Manager = '
                     'CS6903_PGP_Password_Manager.app:app']}

setup_kwargs = {
    'name': 'cs6903-pgp-password-manager',
    'version': '0.1.0',
    'description': 'A secure system for checking in users to small businesses and events (such as libraries or restaurants) to allow businesses to keep track of COVID-19 exposures.',
    'long_description': 'CS6903 Project 2 - Web Based Password Manager using Client Side PGP\n===================================================\n\n[![Black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)\n[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)\n\n* Github Repository:  <https://github.com/joelbcastillo/CS6903-PGP-Password-Manager.git>\n\nDescription\n-----------\n\nThis project is a web-based password manager that utilizes PGP to encrypt passwords and share them among authorized users. The application uses a frontend component (kbpgp.js) to allow users to upload their private key into the browser storage only and perform client-side operations for decrypting secrets. Allow users to upload their public key to perform client-side operations for encrypting secrets.\n\nThis application is similar to existing application such as 1Password, Bitwarden, and LastPass. All of these applications provide a web interface for users to manage their secrets and share them with team members. However, all accounts for these password managers are protected using a password instead of a public-private key pair that is kept under the end users control. It is most similar to the unix `pass` application, which uses GPG and a command-line interface to store and retrieve secrets.\n\nRequirements\n------------\n\n* Keyserver - Organizations deploying this solution will need to have a trusted keyserver to verify user public keys for encryption.\n  * Default keyserver is <https://keys.openpgp.org>\n\nRunning the Code\n\n### Threat Model\n\n* Private Keys Stored in Browser\n  * Threat: Users will be uploading their private key into the sessionstorage for the domain. If the key is not cleared out from sessionstorage after the user logs out (or a specified timeout period) an attacker could access the key and decrypt all of the secrets a user has access to.\n  * Mitigation: When a user logs out or their session times out, the PGP Private Key will be deleted from local browser sessionstorage as designed.\n* Eavesdropping\n  * Threat: It is possible for an attacker / 3rd party to perform a man in the middle attack and capture the traffic from the users browser to the backend server. This traffic, when decrypted, could contain plaintext secrets and metadata that are being sent to be stored in the backend.\n  * Mitigation: By encrypting the secrets using PGP on the user\'s browser, we are able to prevent an attacker from obtaining secrets by performing a man in the middle attack. Instead, the attacker would only see a PGP encrypted string when decrypting TLS traffic.\n* Public Key Revocation\n  * Threat: Users who are no longer supposed to access data in the secret store will be able to access the secrets as long as the secret is encrypted with their public key.\n  * Mitigation:\n    * We will provide a simple front-end interface for revoking a user\'s access to one or more secrets\n      * Secrets will be re-encrypted without the revoked user\'s public key.\n* Password Hygiene\n  * Threat: If a user no longer has access to the secret, but did at some point, they may have an offline copy that would allow them to use the secret.\n  * Mitigation: When a user\'s access to secrets is revoked, a prompt will be displayed to change the secret. Currently optional, as each organization would need to establish a procedure for rotating secrets.\n    * If the secret is not changed, the user would still have had access to the secret when their access was valid.\n* 2-Factor Authentication Not Implemented\n  * Threat: If a user\'s private key is compromised, the attacker would gain access to all of the user\'s secrets\n  * Mitigation: N/A - Multi Factor / 2nd Factor authentication is currently out of scope for this project.\n* Key Hijacking\n  * Threat: It is possible to create a key for a user to spoof their access.\n  * Mitigation: N/A - Out of scope for this application. Users should only encrypt secrets for other user\'s whose identities they have verified through another means.\n* Data Tampering\n  * Threat: An attacker could intercept the data and tamper with the message in transit.\n  * Mitigation: An HMAC will be submitted with the data to ensure data integrity.\n\n### Topic Related Notes\n\nData Origination Spoofing\n\n* We require a users private key for authentication to the web interface. Unless an attacker has control of an authorized users private key, they will not be able to spoof data insertions. \n\nData Replay\n\n* Data will be transmitted with an HMAC and a timestamp to ensure validity of each API call. The timestamp inside the submitted data package will be checked agains the received timestamp to determine if the message is valid. There will be a grace period of X seconds (where X is most likely < 1 second).\n\nChosen Plaintext Attacks\n\n* The output of the GPG encryption algorithm is non-deterministic. As a result, a user would not be able to determine information about the plaintext from the ciphertext\n\n\nDesign\n------\n\n![Decryption Workflow](./documentation/CS6903-PGP-Password-Manager-Workflow-Decryption.png)\n\n![Encryption Workflow](./documentation/CS6903-PGP-Password-Manager-Workflow-Encryption.png)\n\n![Modify Workflow](./documentation/CS6903-PGP-Password-Manager-Workflow-Modify.png)\n\nSchema\n------\n\n### Audit Table\n\n* id - uuid\n* timestamp - datetime\n* user_id - string\n* action_performed - enum\n  * Encrypted Secret\n  * Decrypted Secret\n  * Deleted Secret\n* Inputs (JSON)\n\n### Secrets Table\n\n* id - uuid\n* name - string\n* encrypted_value - binary\n\n### Users Table\n\n* id - uuid\n* key_id - string\n* email - string\n\n### UsersSecrets Table\n\n* id - uuid\n* key_id - string (FK to Users table)\n* secret_id - string (FK to secrets table)\n\nAPI\n---\n\n### `GET /secret`\n\nArgs:\n\n* Key ID\n\nReturns:\n\n```javascript\n[\n  {\n    "id": "SECRET_ID",\n    "name": "SECRET_NAME",\n    "value": "SECRET_VALUE"\n  },\n]\n```\n\n### `POST /secret`\n\nArgs:\n\n* Name\n* Encryption Key IDs\n* Encrypted Value\n\nReturns:\n\n```javascript\n{\n  "id": "SECRET_ID",\n}\n```\n\n### `PUT /secret/<SECRET_ID>`\n\nArgs:\n\n* Name\n* Encryption Key IDs\n* Encrypted Value\n\nReturns:\n\n```javascript\n{\n  "id": "SECRET_ID",\n}\n```\n\n### `DELETE /secret/<SECRET_ID>`\n\nArgs:\n\nReturns:\n\n```javascript\n{\n  "success": "True"\n}\n```\n\nFront-End\n---------\n\nFunctions:\n\n* `load_key(File)`\n* `setupKeyManager()`\n* `encrypt(key_ids[], secret)`\n* `decrypt(privateKey, ciphertext)`\n* `modify(secret_id, key_ids[], secret)`\n* `delete(secret_id, privateKey)`\n\nRoutes\n------\n\n* Login\n* Home\n\nAuthors\n-------\n\n* Ho Yin Kenneth Chan ([@kenliya](https://github.com/kenliya))\n* Gary Zhou ([@g-zhou](https://github.com/g-zhou))\n* Joel Castillo ([@joelbcastillo](https://github.com/joelbcastillo))\n',
    'author': 'Joel Castillo',
    'author_email': 'joel.castillo@nyu.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/joelbcastillo/CS6903-PGP-Password-Manager',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.1,<3.10',
}


setup(**setup_kwargs)
